Jio AirFiber Tracker Android Studio Project

This is an Android WebView project containing the supplied Jio AirFiber Tracker.
The HTML is bundled inside app/src/main/assets/index.html.

Data persistence:
- The HTML version uses localStorage for saved work entries/settings.
- Android WebView DOM storage is enabled in MainActivity, so the saved data persists on the device.

Build:
1. Open this folder in Android Studio.
2. Let Gradle sync.
3. Build > Build APK(s).
4. The debug APK will be under app/build/outputs/apk/debug/.

The Gemini AI section from the supplied HTML still depends on its API configuration; this project does not add or expose a secret API key.
